<?php
session_start();
include('dbcon.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

function sendemail_verify ($name, $email,$verify_token)
{
    $mail = new PHPMailer(true);
    //$mail -> SMTPDeBug = 2;
    $mail->isSMTP();
    $mail->SMTPAuth = true;
    
    $mail->Host ="smtp.gmail.com";
    $mail->Username = "quynhngaphan712@gmail.com";
    $mail->Password = "catf jfua ergi xcjl";

    $mail->SMTPSecure = "tls";
    $mail->Port = 587;

    $mail->setFrom("quynhngaphan712@gmail.com", $name);
    $mail->addAddress($email);

    $mail->isHTML(true);
    $mail->Subject = "Email Verification from Funda of web IT";

    $email_template = "
        <h2>You have Registered with Funda of Web IT</h2>
        <h5>Verify your email address to Login with the below given link</h5>
        <br/><br/>
        <a href='http://localhost/CNPMweb1/verify-email.php?token=$verify_token'> Click me </a>
    ";

    $mail->Body = $email_template;
    $mail->send();
    //echo 'Message has been sent';
}
if(isset($_POST['register_btn']))
{
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $verify_token = md5(rand());

    //Email Exists or not
    $check_email_query = "SELECT email FROM users WHERE email='$email' LIMIT 1";
    $check_email_query_run = mysqli_query($con, $check_email_query);

    if(mysqli_num_rows($check_email_query_run) > 0)
    {
         $_SESSION['status'] = "Email Id alreadly Exits";
         header("Location: register.php");
    }
    else
    {
        //insert user / registered user data
        $query = "INSERT INTO users (name,phone,email,password,verify_token) VALUES ('$name','$phone','$email','$password','$verify_token')";
        $query_run = mysqli_query($con, $query);

        if($query_run)
        {
            sendemail_verify("$name", "$email","$verity_token");
            $_SESSION['status']="Registration Succesfull.! Please verufy your Email Address.";
            header("Location: register.php");

        }
        else
        {
            $_SESSION['status']="Registration Failed";
            header("Location: register.php");

        }
    }
}

?>